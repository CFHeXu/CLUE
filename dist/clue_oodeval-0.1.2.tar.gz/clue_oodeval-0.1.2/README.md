# CLUE
CLUE is a novel metrics suite for automatically evaluating object-oriented designs (i.e., UML class diagram designs).
